
from picamzero import Camera
from time import sleep

cam = Camera()

print("A tirar foto...")
cam.take_photo("teste.jpg")
print("Foto tirada!")

cam.capture_sequence("sequencia.jpg", num_images=3, interval=5)
